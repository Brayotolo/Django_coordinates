from django.http.response import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    return render(request,'home.html',{'name':'Navin'})
def add(request):

    C = request.GET['num1']
    class Point():
     def __init__(self, x, y):
          self.x = x
         self.y = y
 P = []
 e=len(C)
 n=0
 while e>0:
    c=str(C[n])
    coordinate =  c[1] + c[3]
    print(coordinate)
    P.append(Point(c[1],c[3]))
    e=e-1
    n=n+1
    res = (P[0].y)
    return render(request,'result.html',{'result':res})