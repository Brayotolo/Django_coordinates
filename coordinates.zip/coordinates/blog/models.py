from django.db import models
from django.conf import settings

class Post(models.Model):
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    coordinates = models.TextField()
    closest_pair = models.TextField()
    distance = models.TextField()
   

    def _str_(self):
        return self.coordinates